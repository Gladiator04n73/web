# User List

| ID | Name | Email | Type |
|:---|:-----|:------|:-----|
| 1 | John Doe | john.doe@example.com | admin |
| 2 | Jane Smith | jane.smith@example.com | customer |
| 3 | Bob Johnson | bob.johnson@example.com | customer |
| 4 | Alice Williams | alice.williams@example.com | manager |
| 5 | Charlie Brown | charlie.brown@example.com | customer |

## Summary

Total users: **5**

### User Types:

* **Admin**: 1
* **Customer**: 3
* **Manager**: 1
