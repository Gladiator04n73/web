<?php

// User data
return [
    [
        'id' => 1,
        'name' => 'John Doe',
        'email' => 'john.doe@example.com',
        'type' => 'admin'
    ],
    [
        'id' => 2,
        'name' => 'Jane Smith',
        'email' => 'jane.smith@example.com',
        'type' => 'customer'
    ],
    [
        'id' => 3,
        'name' => 'Bob Johnson',
        'email' => 'bob.johnson@example.com',
        'type' => 'customer'
    ],
    [
        'id' => 4,
        'name' => 'Alice Williams',
        'email' => 'alice.williams@example.com',
        'type' => 'manager'
    ],
    [
        'id' => 5,
        'name' => 'Charlie Brown',
        'email' => 'charlie.brown@example.com',
        'type' => 'customer'
    ]
]; 